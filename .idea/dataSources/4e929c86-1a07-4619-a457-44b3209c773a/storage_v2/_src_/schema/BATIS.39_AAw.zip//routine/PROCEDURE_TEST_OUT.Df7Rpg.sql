create PROCEDURE PROCEDURE_TEST_OUT(
    cur out SYS_REFCURSOR
) AS 
BEGIN
  open cur for select * from sys_user;
END PROCEDURE_TEST_OUT;
/

